package com.example.hungnq.customlistview;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyAdapter extends BaseAdapter {

    public Context ctx;
    public LayoutInflater layoutInflater;

    public MyAdapter(Context context) {
        this.ctx=context;
        //generate layout
        layoutInflater = ((Activity)context).getLayoutInflater();
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return MainActivity.ten.length;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        One_item one_item;
        //kiem tra xem view ton tai chua
        if(convertView==null)
        {
            one_item = new One_item();
            //anh xa layout
            convertView = layoutInflater.inflate(R.layout.sample_my_view,null);
            //anh xa id
            one_item.imageView=(ImageView)convertView.findViewById(R.id.imageView1);
            one_item.textView = (TextView)convertView.findViewById(R.id.textView1);
            //set tag
            convertView.setTag(one_item);

        }
        else {
            //neu co view roi thi lay view vao chuong trinh
            one_item = (One_item)convertView.getTag();
        }
        //truyen du lieu
        one_item.imageView.setImageResource(MainActivity.hinh[position]);
        one_item.textView.setText(MainActivity.ten[position]);
        return convertView;
    }

    public static class One_item
    {
        public ImageView imageView;
        public TextView textView;
    }
}

package com.example.hungnq.customlistview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    //khai bao Datasource
    public static int[] hinh = {R.drawable.ic_launcher_background};
    public static String[] ten = {"android","ios","window phone"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView)findViewById(R.id.listview1);

        MyAdapter adapter = new MyAdapter(MainActivity.this);
        listView.setAdapter(adapter);

    }
}

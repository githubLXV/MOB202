package com.example.mob202demo5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Main2ActivityDemo53 extends AppCompatActivity {
    Button btn1, btn2, btn3, btn4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2_demo53);
        btn1 = findViewById(R.id.btn531);
        btn2 = findViewById(R.id.btn532);
        btn3 = findViewById(R.id.btn533);
        btn4 = findViewById(R.id.btn534);
        //1.hien thi dang thong bao
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //1. Tao AlertDialog
                AlertDialog.Builder
                        builder = new AlertDialog.Builder(Main2ActivityDemo53.this);
                //2. Tao noi dung thong baos
                builder.setMessage("Day la noi dung thongbao");
                //3. tieu de
                builder.setTitle("Tieu de");
                //4. xu ly button ok
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"Ban dong y",Toast.LENGTH_LONG).show();
                        dialog.dismiss();//an thong bao
                    }
                });
                //5. xu ly button cancel
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"Ban thoat",Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                    }
                });
                //6. hien thi dialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        //Thong bao dang radio button
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //doc file xml
                final  String[] color = getResources().getStringArray(R.array.color);
                //1.tao moi doi tuong
                AlertDialog.Builder builder
                        = new AlertDialog.Builder(Main2ActivityDemo53.this)
                        .setTitle("Tieu de")
                        .setSingleChoiceItems(color, -1, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                switch (which)
                                {
                                    case 0:
                                        Toast.makeText(getApplicationContext(),"RED",Toast.LENGTH_LONG).show();
                                        break;
                                    case 1:
                                        Toast.makeText(getApplicationContext(),"Green",Toast.LENGTH_LONG).show();
                                        break;
                                    case 2:
                                        Toast.makeText(getApplicationContext(),"Blue",Toast.LENGTH_LONG).show();
                                        break;
                                }
                            }
                        });
                //2. hien thi
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });
        //listview
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               final String[] color = getResources().getStringArray(R.array.color);
               AlertDialog.Builder builder =
                       new AlertDialog.Builder(Main2ActivityDemo53.this)
                       .setTitle("Tieu de")
                       .setItems(R.array.color, new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               Toast.makeText(getApplicationContext(),color[which],Toast.LENGTH_LONG).show();
                           }
                       });
               AlertDialog alertDialog = builder.create();
               alertDialog.show();
            }
        });
        //checkbox
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] color = getResources().getStringArray(R.array.color);
                AlertDialog.Builder builder =
                        new AlertDialog.Builder(Main2ActivityDemo53.this)
                                .setTitle("Tieu de")
                                .setMultiChoiceItems(color, null, new DialogInterface.OnMultiChoiceClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                                        switch (which)
                                        {
                                            case 0:
                                                Toast.makeText(getApplicationContext(),"RED",Toast.LENGTH_LONG).show();
                                                break;
                                            case 1:
                                                Toast.makeText(getApplicationContext(),"Green",Toast.LENGTH_LONG).show();
                                                break;
                                            case 2:
                                                Toast.makeText(getApplicationContext(),"Blue",Toast.LENGTH_LONG).show();
                                                break;
                                        }
                                    }
                                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });
    }
}

package com.example.mob202l6fragment.demo72;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mob202l6fragment.R;
import com.google.android.material.textfield.TextInputLayout;

public class Demo72Main2Activity extends AppCompatActivity {
    Button button;
    TextInputLayout textInputLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo72_main2);
        button = findViewById(R.id.btn72);
        textInputLayout = findViewById(R.id.text_input_layout_72);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textInputLayout.getEditText().length()==0)
                {
                    textInputLayout.setError("Vui long khong de trong");
                }
                else
                {
                    textInputLayout.setError("");
                }
            }
        });
    }
}

package com.example.mob202l6fragment.demo71;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mob202l6fragment.R;
import com.google.android.material.snackbar.Snackbar;

public class Demo71Main2Activity extends AppCompatActivity {
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo71_main2);
        button = findViewById(R.id.btn71);//anh xa
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(findViewById(R.id.btn71),"Thong bao",6000)
                        .setActionTextColor(Color.RED)
                        .setAction("OK", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                //xu ly hanh dong
                            }
                        }).show();
            }
        });
    }
}

package com.example.mob202l6fragment.l62loadfragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.mob202l6fragment.R;


public class L622BlankFragment extends Fragment {
    Button button;

    public L622BlankFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_l622_blank, container, false);
        button = view.findViewById(R.id.frg_l622_btn);
        return view;
    }


}

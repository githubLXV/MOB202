package com.example.mob202l6fragment.demo75;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.mob202l6fragment.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Demo75Main2Activity extends AppCompatActivity {
    FloatingActionButton floatingActionButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo75_main2);
        floatingActionButton = findViewById(R.id.floatingActionButton75);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),
                        "Ban vua click button",Toast.LENGTH_LONG).show();
            }
        });
    }
}

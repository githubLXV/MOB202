package com.example.mob202l6fragment.demo74;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.mob202l6fragment.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Demo74Main2Activity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo74_main2);
        bottomNavigationView = findViewById(R.id.nav74);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId()==R.id.op1)
                {
                    Toast.makeText(getApplicationContext(),"Ban chon 1",Toast.LENGTH_LONG).show();
                }
                else if(item.getItemId()==R.id.op2)
                {
                    Toast.makeText(getApplicationContext(),"Ban chon 2",Toast.LENGTH_LONG).show();
                }
                else if(item.getItemId()==R.id.op3)
                {
                    Toast.makeText(getApplicationContext(),"Ban chon 3",Toast.LENGTH_LONG).show();
                }
                return false;
            }
        });
    }
}

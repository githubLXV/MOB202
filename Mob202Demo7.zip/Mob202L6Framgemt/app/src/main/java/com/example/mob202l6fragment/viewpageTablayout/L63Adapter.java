package com.example.mob202l6fragment.viewpageTablayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class L63Adapter extends FragmentPagerAdapter {
    private final List<Fragment> fragmentList = new ArrayList<>();//danh sach chua frm
    private final  List<String> frgListTitle = new ArrayList<>();//danh sach chua tieu de frm
    //phuong thuc khoi tao
    public L63Adapter(FragmentManager fm)
    {
        super(fm);
    }
    //lay ve cac fragment
    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }
    //lay ve tong so fragment
    @Override
    public int getCount() {
        return fragmentList.size();
    }

    //ham lay title (tieu de)
    @Override
    public CharSequence getPageTitle(int position) {
        return frgListTitle.get(position);
    }
    //ham them fragment vao Activity
    public void addFrag(Fragment fragment,String title)
    {
        fragmentList.add(fragment);//them fagment vao list
        frgListTitle.add(title);//them title vao list
    }
}

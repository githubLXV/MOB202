package com.example.mob202l6fragment.viewpageTablayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.view.ViewParent;

import com.example.mob202l6fragment.R;
import com.google.android.material.tabs.TabLayout;

public class L63Main2Activity extends AppCompatActivity {
    ViewPager viewPager;
    TabLayout tabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l63_main2);
        //1.anh xa viewPager
        viewPager = findViewById(R.id.viewpager_l63);
        //2.anh xa tablayout
        tabLayout = findViewById(R.id.tablayout_l63);
        //3.them tablayout viewpager
        this.addTabs(viewPager);
        tabLayout.setupWithViewPager(viewPager);
    }
    //dinh nghia ham addTabs
    private void addTabs(ViewPager viewPager)
    {
        L63Adapter adapter = new L63Adapter(getSupportFragmentManager());
        adapter.addFrag(new L63BlankFragment1(),"One");
        adapter.addFrag(new L63BlankFragment2(),"Two");
        adapter.addFrag(new L63BlankFragment3(),"Three");
        viewPager.setAdapter(adapter);
    }

}

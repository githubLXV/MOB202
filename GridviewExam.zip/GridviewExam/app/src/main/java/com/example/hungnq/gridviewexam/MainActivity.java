package com.example.hungnq.gridviewexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

public class MainActivity extends AppCompatActivity {

    public static int[] hinh = {R.drawable.apple,R.drawable.blogger,R.drawable.chrome,
            R.drawable.dell,R.drawable.facebook,R.drawable.firefox,R.drawable.hp,R.drawable.android,R.drawable.hancock};
    public static String[] ten = {"apple","blogger","chrome",
            "dell","facebook","firefox","hp","android","hancock"};

    GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = (GridView)findViewById(R.id.gridview1);

        MyAdapter adapter = new MyAdapter(MainActivity.this);
        gridView.setAdapter(adapter);
    }
}

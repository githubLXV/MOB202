package com.example.hungnq.gridviewexam;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyAdapter extends BaseAdapter {
    public Context ctx;
    LayoutInflater layoutInflater;

    public MyAdapter(Context context) {

        this.ctx = context;
        //khoi tao layout
        layoutInflater = ((Activity)context).getLayoutInflater();

    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //khai bao view 1 o
        View_mot_o view_mot_o;
        //kiem tra neu chua co view thi tao view moi
        if(convertView==null)
        {
            view_mot_o = new View_mot_o();
            //gan view voi layout trong xml (anh xa)
            convertView=layoutInflater.inflate(R.layout.sample_my_view,null);
            //gan thanh phan Textview, imageView trong XML (anh xa)
            view_mot_o.imageView=(ImageView)convertView.findViewById(R.id.imageView2);
            view_mot_o.textView = (TextView)convertView.findViewById(R.id.textView2);


            //tao view
            convertView.setTag(view_mot_o);

        }
        else
        {
            view_mot_o = (View_mot_o)convertView.getTag(); //lay ve view
        }

        //truyen du lieu
        view_mot_o.imageView.setImageResource(MainActivity.hinh[position]);
        view_mot_o.textView.setText(MainActivity.ten[position]);

        return convertView;
    }
    public static class View_mot_o
    {
        public ImageView imageView;
        public TextView textView;
    }
}

package com.example.mob202demo5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2ActivityL54 extends AppCompatActivity {
    Button btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2_l54);
        btnLogin = findViewById(R.id.btnL54);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //1.tao dialog
                AlertDialog.Builder builder
                        =new AlertDialog.Builder(Main2ActivityL54.this);
                //2. tao layout lien ket
                LayoutInflater inflater = getLayoutInflater();
                View view = inflater.inflate(R.layout.l54_login_item,null);
                builder.setView(view);
                //3. Lien ket cac truong du lieu trong view
                final EditText user = (EditText)view.findViewById(R.id.txtUser);
                final EditText pass = (EditText)view.findViewById(R.id.txtPass);
                //4.tao title, ok, cancel
                builder.setTitle("My login");
                builder.setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                //5. Gan vao form
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

            }
        });
    }
}

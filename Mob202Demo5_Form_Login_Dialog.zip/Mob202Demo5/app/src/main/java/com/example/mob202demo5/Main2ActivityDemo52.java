package com.example.mob202demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class Main2ActivityDemo52 extends AppCompatActivity {
    Button btn521,btn522;
    //khai bao
    ProgressBar progressBar;
    ProgressDialog progressDialog;
    Handler progressHandler = new Handler();// doi tuong nhan uy nhiem
    //doi tuong uy nhiem se thong bao lien tuc cho nguoi dung
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2_demo52);
        btn521 = findViewById(R.id.btn521);
        btn522 = findViewById(R.id.btn522);
        btn521.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //1. tao moi doi tuong dialog
                progressDialog = new ProgressDialog(Main2ActivityDemo52.this);
                //2. thiet lap tieu de
                progressDialog.setTitle("Downloading.....");
                //3. thiet lap thong bao
                progressDialog.setMessage("Download in processing......");
                //4. dinh nghia kieu hien thi ngang hay doc
                progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                //5. thiet lap min, max
                progressDialog.setProgress(0);
                progressDialog.setMax(20);
                //6. hien thi
                progressDialog.show();
                //7. xu ly doi tuong uy nhiem
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            while (progressDialog.getProgress() <= progressDialog.getMax()) {
                                Thread.sleep(1000);//cứ 2s thông báo 1 lần
                                progressHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        progressDialog.incrementProgressBy(1);
                                    }
                                });
                                //sau khi da hoan thanh cong viec, an thong bao
                                if (progressDialog.getProgress() == progressDialog.getMax()) {
                                    progressDialog.dismiss();
                                }
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
        ////Xu ly button 2
        btn522.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final  ProgressDialog p
                         = ProgressDialog.show(Main2ActivityDemo52.this,
                        "Please wait...","Downloading...",true);
                p.setCancelable(true);//cho phep huy khi dang download
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });

    }
}

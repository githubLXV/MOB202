package com.example.mob202demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;

public class Main2ActivityDemo51 extends AppCompatActivity {
    Button btnDate,btnTime;
    TextView txtDate,txtTime;
    Calendar calendar = Calendar.getInstance();//tao doi tuong ngay thang
    final int hour1 = calendar.get(Calendar.HOUR_OF_DAY);//lay gio
    final int minute1 = calendar.get(Calendar.MINUTE);//lay phut
    DatePickerDialog datePickerDialog;//doi tuong chon ngay
    TimePickerDialog timePickerDialog;//doi tuong chon thoi gian
    Context context = this;//ngữ cảnh là Main2ActivityDemo51
    Calendar c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2_demo51);
        //anh xa
        btnDate = findViewById(R.id.btnDate);
        btnTime = findViewById(R.id.btnTime);
        txtDate = findViewById(R.id.txtDate);
        txtTime = findViewById(R.id.txtTime);
        //xu ly button time
        btnTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //1.tao moi doi tuong timpicker
                //ham co 5 tham so: TimePickerDialog(context,ham,hour1,minute1,is24h);
                timePickerDialog = new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        //noi dung ham
                        txtTime.setText((hourOfDay+":"+minute));//dua gio, phut len Textview
                    }
                },hour1,minute1,android.text.format.DateFormat.is24HourFormat(context));
                //2. hien thi
                timePickerDialog.show();
            }
        });
        //xu ly button date

        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 c=Calendar.getInstance();
                 int day2 = c.get(Calendar.DAY_OF_MONTH);
                 int month2 = c.get(Calendar.MONTH);
                 int year2 = c.get(Calendar.YEAR);
                 //DatePickerDialog(context,ham,day,month,year);
                 datePickerDialog
                         =new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
                     @Override
                     public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                         txtDate.setText(dayOfMonth+"/"+(month+1)+"/"+year);
                     }
                 },day2,month2,year2);
                 //hien thi
                datePickerDialog.show();


            }
        });
    }
}

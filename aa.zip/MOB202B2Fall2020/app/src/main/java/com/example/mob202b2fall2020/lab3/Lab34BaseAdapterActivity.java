package com.example.mob202b2fall2020.lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.mob202b2fall2020.R;

import java.util.ArrayList;
import java.util.List;

public class Lab34BaseAdapterActivity extends AppCompatActivity {
    List<Contact> ls = new ArrayList<>();
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab34_base_adapter);
        ls.add(new Contact("Nguyen Van An","18",R.mipmap.ic_launcher));
        ls.add(new Contact("Nguyen Van An","18",R.mipmap.ic_launcher));
        ls.add(new Contact("Nguyen Van An","18",R.mipmap.ic_launcher));
        ls.add(new Contact("Nguyen Van An","18",R.mipmap.ic_launcher));
        ls.add(new Contact("Nguyen Van An","18",R.mipmap.ic_launcher));

        listView = findViewById(R.id.lab34listview);
        CustomAdapter adapter = new CustomAdapter(ls,this);
        listView.setAdapter(adapter);

    }
}
package com.example.mob202b2fall2020.lab5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mob202b2fall2020.R;

public class L53DialogActivity extends AppCompatActivity {
    Button btn1,btn2,btn3,btn4,btnLogin;
    Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l53_dialog);
        btn1 = findViewById(R.id.l53btn1);
        btn2 = findViewById(R.id.l53btn2);
        btn3 = findViewById(R.id.l53btn3);
        btn4 = findViewById(R.id.l53btn4);
        btnLogin = findViewById(R.id.l53BtnLogin);
        //dialog thong bao
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder =
                        new AlertDialog.Builder(context);
                builder.setTitle("Tieu de thong bao");
                builder.setMessage("noi dung thong bao");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context,"ban chon OK",Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context,"ban chon Cancel",Toast.LENGTH_SHORT).show();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        ////////dialog radio button
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] color = getResources().getStringArray(R.array.color1);
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Title");
                builder.setSingleChoiceItems(color, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which)
                        {
                            case 0:
                                Toast.makeText(context,"ban chon RED",Toast.LENGTH_SHORT).show();
                                break;
                            case 1:
                                Toast.makeText(context,"ban chon BLUE",Toast.LENGTH_SHORT).show();
                                break;
                            case 2:
                                Toast.makeText(context,"ban chon GREEN",Toast.LENGTH_SHORT).show();
                                break;

                        }
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }

        });
        ///////dialog listview
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] color = getResources().getStringArray(R.array.color1);
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Title");
                builder.setItems(R.array.color1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context,color[which],Toast.LENGTH_LONG).show();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        /////dialog combobox
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] color = getResources().getStringArray(R.array.color1);
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Title");
                builder.setMultiChoiceItems(color, null, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        switch (which)
                        {
                            case 0:
                                Toast.makeText(context,"RED",Toast.LENGTH_SHORT).show();
                                break;
                            case 1:
                                Toast.makeText(context,"BLUE",Toast.LENGTH_SHORT).show();
                                break;
                            case 2:
                                Toast.makeText(context,"GREEN",Toast.LENGTH_SHORT).show();
                                break;

                        }
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        ////////////add form to dialog
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                LayoutInflater inflater = getLayoutInflater();
                View view = inflater.inflate(R.layout.l53_login_form,null);
                builder.setView(view);
                final EditText user = (EditText)view.findViewById(R.id.l53TxtUser);
                final  EditText pass = (EditText)view.findViewById(R.id.l53TxtPass);
                builder.setTitle("Login");
                builder.setCancelable(false);
                builder.setPositiveButton("Login", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context,"Ban vua nhap"+user.getText()+"; "+pass.getText(),Toast.LENGTH_LONG).show();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

    }
}
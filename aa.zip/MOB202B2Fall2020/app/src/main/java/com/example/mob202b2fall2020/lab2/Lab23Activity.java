package com.example.mob202b2fall2020.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mob202b2fall2020.R;

public class Lab23Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab23);
    }
}
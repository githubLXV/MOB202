package com.example.mob202b2fall2020.lab4mob202;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.mob202b2fall2020.R;

public class L4B3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l4_b3);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu1,menu);//tao menu
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.it1)
        {
            Toast.makeText(getApplicationContext(),item.getTitle(),Toast.LENGTH_SHORT).show();
        }
        else if(item.getItemId()==R.id.it2)
        {
            Toast.makeText(getApplicationContext(),item.getTitle(),Toast.LENGTH_SHORT).show();
        }
        else if(item.getItemId()==R.id.it3)
        {
            Toast.makeText(getApplicationContext(),item.getTitle(),Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}
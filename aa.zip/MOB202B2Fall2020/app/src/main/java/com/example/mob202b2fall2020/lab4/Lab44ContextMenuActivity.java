package com.example.mob202b2fall2020.lab4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mob202b2fall2020.R;

public class Lab44ContextMenuActivity extends AppCompatActivity {
    ListView listView;
    String[] arr = new String[]{"Item1","Item2","Item3","Item4","Item5"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab44_context_menu);
        listView = findViewById(R.id.lab44listview);
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,arr);
        listView.setAdapter(adapter);

        registerForContextMenu(listView);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.lab42,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.pu1)
        {
            Toast.makeText(getApplicationContext(),"Ban chon Popup1",Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId()==R.id.pu2)
        {
            Toast.makeText(getApplicationContext(),"Ban chon Popup2",Toast.LENGTH_SHORT).show();
        }
        return super.onContextItemSelected(item);
    }
}
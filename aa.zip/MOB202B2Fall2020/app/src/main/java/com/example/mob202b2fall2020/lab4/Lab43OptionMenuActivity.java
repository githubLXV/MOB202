package com.example.mob202b2fall2020.lab4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.mob202b2fall2020.R;

public class Lab43OptionMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab43_option_menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.lab42,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.pu1)
        {
            Toast.makeText(getApplicationContext(),"Ban chon Popup1",Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId()==R.id.pu2)
        {
            Toast.makeText(getApplicationContext(),"Ban chon Popup2",Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}
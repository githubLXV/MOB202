package com.example.mob202b2fall2020.lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.mob202b2fall2020.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Lab31Activity extends AppCompatActivity {
    ListView listView;
    List<HashMap<String,Object>> list = new ArrayList<>();//nguon du lieu
    String[] from = {"name","age","pic"};
    int[] to = {R.id.lab31ItemName,R.id.lab31ItemAge,R.id.lab31ItemImage};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab31);
        listView = findViewById(R.id.lab31listview);
        //dua du lieu vao nguon du lieu
        HashMap<String,Object> hashMap = new HashMap<>();
        hashMap.put("name","Nguyen Van A");
        hashMap.put("age",18);
        hashMap.put("pic",R.mipmap.ic_launcher);
        list.add(hashMap);
        ///////
        hashMap = new HashMap<>();
        hashMap.put("name","Tran Van B");
        hashMap.put("age",19);
        hashMap.put("pic",R.mipmap.ic_launcher);
        list.add(hashMap);

        SimpleAdapter adapter =
                new SimpleAdapter(this,list,R.layout.lab31_listview_item,from,to);
        listView.setAdapter(adapter);


    }
}
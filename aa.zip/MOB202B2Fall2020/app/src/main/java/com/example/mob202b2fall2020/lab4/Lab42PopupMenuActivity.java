package com.example.mob202b2fall2020.lab4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mob202b2fall2020.R;

public class Lab42PopupMenuActivity extends AppCompatActivity {
    Button btn;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab42_popup_menu);
        btn = findViewById(R.id.lab42btn1);
        tv  = findViewById(R.id.lab42textView);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(Lab42PopupMenuActivity.this,tv);
                MenuInflater inflater = popupMenu.getMenuInflater();
                inflater.inflate(R.menu.lab42,popupMenu.getMenu());

                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if(item.getItemId()==R.id.pu1)
                        {
                            Toast.makeText(getApplicationContext(),"Ban chon Popup1",Toast.LENGTH_SHORT).show();
                        }
                        if(item.getItemId()==R.id.pu2)
                        {
                            Toast.makeText(getApplicationContext(),"Ban chon Popup2",Toast.LENGTH_SHORT).show();
                        }
                        return false;
                    }
                });
                popupMenu.show();
            }
        });
    }
}
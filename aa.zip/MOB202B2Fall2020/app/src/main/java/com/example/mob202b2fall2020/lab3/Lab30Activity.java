package com.example.mob202b2fall2020.lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.mob202b2fall2020.R;

public class Lab30Activity extends AppCompatActivity {
    //array adapter
    //b1: tao nguon du lieu
    //b2: lien ket nguon du lieu voi adapter
    //b3: dua du lieu len adapterview
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab30);
        listView = findViewById(R.id.lab30listview);
        //b1
        String[] arr = new String[]{
                "Gia tri 1","Gia tri 2","Gia tri 3","Gia tri 4","Gia tri 5",
        };
        //b2
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,arr);
        //b3:
        listView.setAdapter(adapter);

    }
}
package com.example.mob202b2fall2020.lab3;

public class Contact {
    private String name;
    private String age;
    private int image;

    public Contact(String name, String age, int image) {
        this.name = name;
        this.age = age;
        this.image = image;
    }

    public Contact() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}

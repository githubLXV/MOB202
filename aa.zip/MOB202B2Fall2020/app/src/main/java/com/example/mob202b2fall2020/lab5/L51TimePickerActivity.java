package com.example.mob202b2fall2020.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import com.example.mob202b2fall2020.R;

import java.util.Calendar;

public class L51TimePickerActivity extends AppCompatActivity {
    Button btnTime,btnDate;
    TextView lblTime,lblDate;
    Context context = this;
    Calendar calendar = Calendar.getInstance();
    final int hour = calendar.get(Calendar.HOUR_OF_DAY);
    final int minute1 = calendar.get(Calendar.MINUTE);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l51_time_picker);
        btnTime = findViewById(R.id.l51btn1);
        lblTime = findViewById(R.id.l51lbltime);
        btnDate = findViewById(R.id.l51btnDate);
        lblDate = findViewById(R.id.l51lblDate);

        btnTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(L51TimePickerActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        lblTime.setText(hourOfDay+":"+minute);
                    }
                },hour,minute1,android.text.format.DateFormat.is24HourFormat(context));
                timePickerDialog.show();
            }
        });
        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance();
                int day1 = c.get(Calendar.DAY_OF_MONTH);
                int month1 = c.get(Calendar.MONTH);
                int year1 = c.get(Calendar.YEAR);
                DatePickerDialog dp = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        lblDate.setText(dayOfMonth+"/"+month+1+"/"+year);
                    }
                },day1,month1,year1);
                dp.show();
            }

        });
    }
}
package com.example.mob202b2fall2020.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

import com.example.mob202b2fall2020.R;

public class Lab21Activity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab21);
        textView = findViewById(R.id.lab21Textview1);
        Typeface font = Typeface.createFromAsset(getAssets(),"Blazed.ttf");
        textView.setTypeface(font);
    }
}
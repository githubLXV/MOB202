package com.example.mob202b2fall2020.lab1Mob202;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mob202b2fall2020.R;

public class Lab12Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab12);
    }
}
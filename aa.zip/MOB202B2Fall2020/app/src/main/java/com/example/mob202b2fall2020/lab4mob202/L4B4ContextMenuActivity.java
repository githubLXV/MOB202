package com.example.mob202b2fall2020.lab4mob202;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mob202b2fall2020.R;

public class L4B4ContextMenuActivity extends AppCompatActivity {
    ListView listView;
    String[] arr = new String[]{"San pham 1","San pham 2","San pham 4","San pham 6"
    ,"San pham 5"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l4_b4_context_menu);
        listView = findViewById(R.id.l4b4lisview);
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,arr);
        listView.setAdapter(adapter);
        registerForContextMenu(listView);
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
       getMenuInflater().inflate(R.menu.menu1,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info
                =(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int index = info.position;

        if(item.getItemId()==R.id.it1)
        {
            Toast.makeText(getApplicationContext(),item.getTitle()+" of "+arr[index].toString(),Toast.LENGTH_SHORT).show();
        }
        else if(item.getItemId()==R.id.it2)
        {
            Toast.makeText(getApplicationContext(),item.getTitle()+" of "+arr[index].toString(),Toast.LENGTH_SHORT).show();
        }
        else if(item.getItemId()==R.id.it3)
        {
            Toast.makeText(getApplicationContext(),item.getTitle()+" of "+arr[index].toString(),Toast.LENGTH_SHORT).show();
        }
        return super.onContextItemSelected(item);
    }
}
package com.example.mob202b2fall2020.lab2mob202;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

import com.example.mob202b2fall2020.R;

public class Mob202Bai1Activity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mob202_bai1);
        textView = findViewById(R.id.mob202lab21textView);
        Typeface font = Typeface.createFromAsset(getAssets(),"Blazed.ttf");
        textView.setTypeface(font);
    }
}
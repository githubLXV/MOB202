package com.example.mob202b2fall2020.lab3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mob202b2fall2020.R;

import java.util.List;

public class CustomAdapter extends BaseAdapter {
    private List<Contact> arrContact;
    private Context context;
    private LayoutInflater inflater;
    public class ContactViewHolder {
        TextView txtName,txtAge;
        ImageView imgPic;
    }
    public CustomAdapter(List<Contact> arrContact,Context context)
    {
        this.context = context;
        this.arrContact = arrContact;
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return arrContact.size();
    }

    @Override
    public Object getItem(int position) {
        return arrContact.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }
    //tao giao dien va gan du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ContactViewHolder viewHolder = new ContactViewHolder();
        if(convertView==null)
        {
            convertView = inflater.inflate(R.layout.lab31_listview_item,null);//tao khung layout
            viewHolder.txtName = (TextView)convertView.findViewById(R.id.lab31ItemName);
            viewHolder.txtAge = (TextView)convertView.findViewById(R.id.lab31ItemAge);
            viewHolder.imgPic = (ImageView)convertView.findViewById(R.id.lab31ItemImage);
            //tao
            convertView.setTag(viewHolder);
        }
        else
        {
            viewHolder = (ContactViewHolder)convertView.getTag(); //lay ve
        }
        //tao du lieu
        viewHolder.txtName.setText(arrContact.get(position).getName());
        viewHolder.txtAge.setText(arrContact.get(position).getAge());
        viewHolder.imgPic.setImageResource(arrContact.get(position).getImage());
        return convertView;
    }
}

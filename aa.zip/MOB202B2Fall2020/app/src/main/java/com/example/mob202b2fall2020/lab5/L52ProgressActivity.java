package com.example.mob202b2fall2020.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import com.example.mob202b2fall2020.R;

public class L52ProgressActivity extends AppCompatActivity {
 Button btn1,btn2;
 ProgressBar progressBar;
 ProgressDialog progressDialog;
 Handler progressHandler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l52_progress);
        btn1  = findViewById(R.id.l52btn1);
        btn2 = findViewById(R.id.l52btn2);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog = new ProgressDialog(L52ProgressActivity.this);
                progressDialog.setTitle("Downloading...");
                progressDialog.setMessage("Download in process...");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                progressDialog.setProgress(0);
                progressDialog.setMax(20);
                progressDialog.show();

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while (progressDialog.getProgress() <= progressDialog.getMax())
                        {
                            try {
                                Thread.sleep(2000);
                                progressHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        progressDialog.incrementProgressBy(2);
                                    }
                                });
                                if(progressDialog.getProgress()==progressDialog.getMax())
                                {
                                    progressDialog.dismiss();
                                }
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }).start();
            }
        });
    }
}
package giaodienLab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.mob202b2fall2020.R;
import com.example.mob202b2fall2020.lab3.Lab34BaseAdapterActivity;

import java.util.ArrayList;
import java.util.List;

public class L34GiaoDienActivity extends AppCompatActivity {
    ListView listView;
    List<DanhBa> list = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l34_giao_dien);
        listView = findViewById(R.id.lab34giaodienListview);

        list.add(new DanhBa("Nguyen Van B","20",R.mipmap.ic_launcher));
        list.add(new DanhBa("Vu Van C","22",R.mipmap.ic_launcher));
        list.add(new DanhBa("Tran Van B","33",R.mipmap.ic_launcher));
        list.add(new DanhBa("Nguyen Van B","20",R.mipmap.ic_launcher));


        L34GiaoDienAdapter adapter = new
                L34GiaoDienAdapter(this,list);
        listView.setAdapter(adapter);
    }
}
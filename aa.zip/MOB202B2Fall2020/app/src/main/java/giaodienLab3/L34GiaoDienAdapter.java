package giaodienLab3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mob202b2fall2020.R;

import java.util.List;

public class L34GiaoDienAdapter extends BaseAdapter {
    private Context context;
    private List<DanhBa> list;
    private LayoutInflater inflater;
    public class DanhBaViewHolder {
        TextView txtName,txtAge;
        ImageView imgImage;
    }
    public L34GiaoDienAdapter(Context context,List<DanhBa> list)
    {
        this.list = list;
        this.context = context;
        //generate layout
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }
    //create view and set data for view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        DanhBaViewHolder viewHolder = new DanhBaViewHolder();
        if(convertView==null)
        {
            //create new view
            convertView = inflater.inflate(R.layout.lab31_giaodien_listview_item,null);
            viewHolder.imgImage = (ImageView)convertView.findViewById(R.id.lab31GiaoDienItemImage);
            viewHolder.txtAge = (TextView)convertView.findViewById(R.id.lab31GiaoDienItemTxtAge);
            viewHolder.txtName = (TextView)convertView.findViewById(R.id.lab31GiaoDienItemTxtName);
            //create a template for view
            convertView.setTag(viewHolder);
        }
        else
        {
            //get view
            viewHolder = (DanhBaViewHolder)convertView.getTag();
        }
        //set data for view
        viewHolder.txtName.setText(list.get(position).getName());
        viewHolder.txtAge.setText(list.get(position).getAge());
        viewHolder.imgImage.setImageResource(list.get(position).getImage());
        //return
        return convertView;
    }
}

package giaodienLab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.mob202b2fall2020.R;

public class Lab36SpinerActivity extends AppCompatActivity {
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab36_spiner);
        spinner = findViewById(R.id.lab36spinner);
        String[] arr = new String[]{
                "Item 1","Item 2","Item 3","Item 4"
        };

        ArrayAdapter<String> adapter  =
                new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,arr);
        spinner.setAdapter(adapter);
    }
}
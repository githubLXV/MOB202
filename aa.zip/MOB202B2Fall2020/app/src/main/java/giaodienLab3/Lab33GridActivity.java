package giaodienLab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;

import com.example.mob202b2fall2020.R;

import java.util.ArrayList;
import java.util.List;

public class Lab33GridActivity extends AppCompatActivity {
    List<DanhBa> list = new ArrayList<>();
    GridView gridView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab33_grid);
        gridView = findViewById(R.id.lab33Gridview);

        list.add(new DanhBa("Nguyen Van BDDDD","20",R.mipmap.ic_launcher));
        list.add(new DanhBa("Vu Van CDDD","22",R.mipmap.ic_launcher));
        list.add(new DanhBa("Tran Van BDDDD","33",R.mipmap.ic_launcher));
        list.add(new DanhBa("Nguyen Van BDDD","20",R.mipmap.ic_launcher));


        GridViewAdapter adapter = new
                GridViewAdapter(this,list);
        gridView.setAdapter(adapter);
    }
}
package giaodienLab3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mob202b2fall2020.R;

import java.util.List;

public class GridViewAdapter extends BaseAdapter {
    private Context context;
    private List<DanhBa> list;
    private LayoutInflater inflater;
    public class DanhBaViewHolder2 {
        TextView txtName,txtAge;
        ImageView imgImage;
    }
    public GridViewAdapter(Context context,List<DanhBa> list)
    {
        this.list = list;
        this.context = context;
        //generate layout
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }
    //create view and set data for view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        DanhBaViewHolder2 viewHolder = new DanhBaViewHolder2();
        if(convertView==null)
        {
            //create new view
            convertView = inflater.inflate(R.layout.lab33_grid_item,null);
            viewHolder.imgImage = (ImageView)convertView.findViewById(R.id.lab33GridViewImage);
            viewHolder.txtAge = (TextView)convertView.findViewById(R.id.lab33GridViewtxtAge);
            viewHolder.txtName = (TextView)convertView.findViewById(R.id.lab33GridViewtxtName);
            //create a template for view
            convertView.setTag(viewHolder);
        }
        else
        {
            //get view
            viewHolder = (DanhBaViewHolder2)convertView.getTag();
        }
        //set data for view
        viewHolder.txtName.setText(list.get(position).getName());
        viewHolder.txtAge.setText(list.get(position).getAge());
        viewHolder.imgImage.setImageResource(list.get(position).getImage());
        //return
        return convertView;
    }
}


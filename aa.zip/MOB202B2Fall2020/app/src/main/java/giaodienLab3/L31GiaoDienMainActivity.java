package giaodienLab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.mob202b2fall2020.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class L31GiaoDienMainActivity extends AppCompatActivity {
    List<HashMap<String,Object>> list = new ArrayList<>();
    String[] from = {"image","name","age"};
    int[] to = {R.id.lab31GiaoDienItemImage,R.id.lab31GiaoDienItemTxtName,
                R.id.lab31GiaoDienItemTxtAge};
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l31_giao_dien_main);
        listView = findViewById(R.id.l31giaodienLisview);

        HashMap<String,Object> hm = new HashMap<>();
        hm.put("name","Nguyen van a");
        hm.put("age",18);
        hm.put("image",R.mipmap.ic_launcher);
        list.add(hm);
        hm = new HashMap<>();
        hm.put("name","Tran van B");
        hm.put("image",R.mipmap.ic_launcher);
        hm.put("age",19);
        list.add(hm);
        hm = new HashMap<>();
        hm.put("name","Vu van C");
        hm.put("image",R.mipmap.ic_launcher);
        hm.put("age",18);
        list.add(hm);

        SimpleAdapter adapter = new
                SimpleAdapter(this,list,R.layout.lab31_giaodien_listview_item,from,to);
        listView.setAdapter(adapter);


    }
}
package com.example.mob202demo8.navigation82;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.mob202demo8.R;
import com.google.android.material.navigation.NavigationView;

public class Demo82Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo82_main2);
        DrawerLayout drawerLayout = findViewById(R.id.draw_layout_82);
        NavigationView navigationView = findViewById(R.id.nav_82);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if(menuItem.getItemId()==R.id.item1)
                {
                    Toast.makeText(getApplicationContext(),"Lua chon 1",Toast.LENGTH_LONG).show();
                    drawerLayout.closeDrawer(GravityCompat.START);//thoat menu
                }
                else if(menuItem.getItemId()==R.id.item2)
                {
                    Toast.makeText(getApplicationContext(),"Lua chon 2",Toast.LENGTH_LONG).show();
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
                else if(menuItem.getItemId()==R.id.item3)
                {
                    Toast.makeText(getApplicationContext(),"Lua chon 3",Toast.LENGTH_LONG).show();
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
                return false;
            }
        });
    }
}

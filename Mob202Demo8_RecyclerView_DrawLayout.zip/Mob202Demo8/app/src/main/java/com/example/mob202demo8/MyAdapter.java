package com.example.mob202demo8;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>  {
    List<Contact> list;
    Context context;
    public MyAdapter(List<Contact> list, Context context) {
        this.list = list;
        this.context = context;
    }
    //1.tao view
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_view_81,null);
        return new ViewHolder(view);
    }
    //2. gan du lieu
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.textView.setText(list.get(position).getName());
        holder.imageView.setImageResource(list.get(position).getPic());
    }
    //3. lay ve tong so item
    @Override
    public int getItemCount() {
        return list.size();
    }
    //ĐỊnh nghĩa lớp liên kết với layout Itemview
    public static class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView imageView;
        public TextView textView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            //anh xa
            imageView = itemView.findViewById(R.id.imageView81);
            textView = itemView.findViewById(R.id.textView81);
        }
    }
}

package com.example.mob202demo8;
//dịnh nghĩa model cho Contact
public class Contact {
    private String name;
    private int pic;

    public Contact(String name, int pic) {
        this.name = name;
        this.pic = pic;
    }

    public Contact() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPic() {
        return pic;
    }

    public void setPic(int pic) {
        this.pic = pic;
    }
}

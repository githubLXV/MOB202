package com.example.mob202demo8;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    List<Contact> contacts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerview81);
        //Dinh nghia nguon du lieu
        contacts.add(new Contact("NGuyenVan An",R.mipmap.ic_launcher));
        contacts.add(new Contact("TRan van Binh",R.mipmap.ic_launcher));
        contacts.add(new Contact("Vu Van  Cong",R.mipmap.ic_launcher));
        contacts.add(new Contact("Le dinh Dung",R.mipmap.ic_launcher));
        contacts.add(new Contact("Trinh thi Em",R.mipmap.ic_launcher));
        //goi recyclwrview
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        MyAdapter adapter = new MyAdapter(contacts,this);
        recyclerView.setAdapter(adapter);
    }
}

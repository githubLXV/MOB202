package com.example.mob202demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class Main2ActivityPopup extends AppCompatActivity {
    Button button;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2_popup);
        button = findViewById(R.id.btn403popup);
        textView = findViewById(R.id.lbl403Textview);
        //khi click button thi
        //se gan Popup menu vao textview
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //1. Dang ky
                PopupMenu popupMenu = new PopupMenu(Main2ActivityPopup.this,textView);
                //2. lay menu XML dua vao code Java
                MenuInflater inflater = (MenuInflater)popupMenu.getMenuInflater();
                //3. Render menu
                inflater.inflate(R.menu.popup_menu403,popupMenu.getMenu());
                //4. hien thi menu
                popupMenu.show();
                //5. xu ly su kien
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if(item.getItemId()==R.id.popup4031)
                        {
                            Toast.makeText(getApplicationContext(),"Lua chon 1",Toast.LENGTH_LONG).show();
                        }
                        else if(item.getItemId()==R.id.popup4032)
                        {
                            Toast.makeText(getApplicationContext(),"Lua chon 2",Toast.LENGTH_LONG).show();
                        }
                        else if(item.getItemId()==R.id.popup4033)
                        {
                            Toast.makeText(getApplicationContext(),"Lua chon 3",Toast.LENGTH_LONG).show();
                        }
                        return false;
                    }
                });
            }
        });
    }
}

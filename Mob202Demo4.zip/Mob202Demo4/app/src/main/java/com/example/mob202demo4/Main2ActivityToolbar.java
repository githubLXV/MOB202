package com.example.mob202demo4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

public class Main2ActivityToolbar extends AppCompatActivity {
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2_toolbar);
        toolbar = (Toolbar) findViewById(R.id.toolbar404);
        setSupportActionBar(toolbar);//goi lenh ho tro su dung toolbar
        //ho tro xu ly phim home
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //set logo
        toolbar.setLogo(R.mipmap.ic_launcher);
        //ho tro dieu huong
        toolbar.setNavigationIcon(R.drawable.ic_launcher_background);

    }
}

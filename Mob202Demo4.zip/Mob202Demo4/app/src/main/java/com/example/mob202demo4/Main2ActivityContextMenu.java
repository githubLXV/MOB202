package com.example.mob202demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Main2ActivityContextMenu extends AppCompatActivity {
    ListView listView;
    String[] mang = {"Cam","Oi","Huong duong","Nuoc"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2_context_menu);
        listView = findViewById(R.id.listview402);
        ArrayAdapter<String> arrayAdapter
                =new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,mang);
        listView.setAdapter(arrayAdapter);
        registerForContextMenu(listView);//dang ky contextmenu cho listview
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.menu_context402,menu);//lien ket menu XML vao code java
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        //lay thong tin ve menu
        AdapterView.AdapterContextMenuInfo info
                =(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int i = info.position;//lay vi tri cua item
        if(item.getItemId()==R.id.can402)
        {
            Toast.makeText(this,"Ban theo Can",Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId()==R.id.cap402)
        {
            Toast.makeText(this,"Ban theo Cap",Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId()==R.id.khoi402)
        {
            Toast.makeText(this,"Ban theo Khoi",Toast.LENGTH_LONG).show();
        }
        return super.onContextItemSelected(item);
    }
}

package com.example.demo3mob202;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Main2Activity extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView = findViewById(R.id.l32listview);
        //1. tao nguon du lieu
        List<HashMap<String,Object>> ds = new ArrayList<>();//tao danh sach doi tuong
        HashMap<String,Object> hm = new HashMap<>();//tao doi tuong Empty
        hm.put("name","Nguyen Van A");//them du lieu vao doi tuong: ten
        hm.put("pic",R.mipmap.ic_launcher);//them du lieu vao doi tuong: anh
        hm.put("age",20);////them du lieu vao doi tuong: tuoi
        ds.add(hm);//dua doi tuong vao danh sach

        hm = new HashMap<>();//tao doi tuong Empty
        hm.put("name","Tran Van B");//them du lieu vao doi tuong: ten
        hm.put("pic",R.mipmap.ic_launcher);//them du lieu vao doi tuong: anh
        hm.put("age",18);////them du lieu vao doi tuong: tuoi
        ds.add(hm);//dua doi tuong vao danh sach

        hm = new HashMap<>();//tao doi tuong Empty
        hm.put("name","Vu Van C");//them du lieu vao doi tuong: ten
        hm.put("pic",R.mipmap.ic_launcher);//them du lieu vao doi tuong: anh
        hm.put("age",21);////them du lieu vao doi tuong: tuoi
        ds.add(hm);//dua doi tuong vao danh sach
        //2. dinh nghia noi gui (from) va noi nhan (to)
        String[] from = {"name","pic","age"};
        int[] to= {R.id.l32_tvName,R.id.l32_pic,R.id.l32_tvAge};
        //3. Tao adapter
        SimpleAdapter adapter
                =new SimpleAdapter(this,ds,R.layout.l32_listview_item,from,to);
        //4. gan adapter vao view
        listView.setAdapter(adapter);
    }
}

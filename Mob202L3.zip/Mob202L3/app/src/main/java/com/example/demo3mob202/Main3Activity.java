package com.example.demo3mob202;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {
    ListView listView;
    String[] name = {"Item 1","Item 2","Item 3"};
    int[] pic = {R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        listView = findViewById(R.id.l33listview);
        CustomAdapter adapter = new CustomAdapter();
        listView.setAdapter(adapter);
    }
    public class CustomAdapter extends BaseAdapter{
        //tong so ban ghi
        @Override
        public int getCount() {
            return pic.length;//do dai cua mang
        }
        //lay ve 1 item
        @Override
        public Object getItem(int position) {
            return null;
        }
        //lay ve id cua item
        @Override
        public long getItemId(int position) {
            return 0;
        }
        //lay ve view cua item
        //nhiem vu: dua view l33_list_view.xml vao getView
        //-> tao 1 lop de chua view l33_list_view.xml
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ///////////////////Tao view
            //gan layout va khoi tao View 1 o
            ViewOneCell cell;
            //2.kiem tra: neu da ton tai view thi goi view ra; neu chua ton tai view thi tao moi
            if(convertView==null)//khong ton tai view, can tao view moi
            {
                cell = new ViewOneCell();
                //lien ket view voi convertview
                LayoutInflater layoutInflater = getLayoutInflater();//doi tuong sinh layout
                //anh xa view
                convertView = layoutInflater.inflate(R.layout.l33_listview_item,null);
                //anh xa tung thanh phan cua view
                cell.img = (ImageView)convertView.findViewById(R.id.l33_img);
                cell.tv = (TextView)convertView.findViewById(R.id.l33_tv);
                //tao view
                convertView.setTag(cell);
            }
            else //neu da ton tai view
            {
                cell = (ViewOneCell)convertView.getTag();//goi view da ton tai ra
            }
            ////////////////ket thuc tao view////////////
            //3. cap nhat du lieu cho view
            cell.img.setImageResource(pic[position]);
            cell.tv.setText(name[position]);
            return convertView;
        }
    }
    public static class ViewOneCell{
        public ImageView img;
        public TextView tv;
    }
}

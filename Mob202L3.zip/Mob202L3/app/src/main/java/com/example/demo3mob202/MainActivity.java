package com.example.demo3mob202;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    Spinner spinner1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner1 = findViewById(R.id.l31spinner);
        //1.khai báo nguồn dữ liệu -> su dung mang
        String[] items = {"Viet Nam","Trung QUoc","Han QUoc","Nhat Ban"};
        //2.khai bao adapter
        //co 3 tham so(context, layout, data)
        ArrayAdapter<String> arrayAdapter
                = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,items);
        //3. gan adapter vao view
        spinner1.setAdapter(arrayAdapter);

    }
}

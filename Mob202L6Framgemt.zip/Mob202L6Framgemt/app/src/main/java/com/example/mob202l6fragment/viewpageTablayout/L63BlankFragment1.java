package com.example.mob202l6fragment.viewpageTablayout;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mob202l6fragment.R;

public class L63BlankFragment1 extends Fragment {

    public L63BlankFragment1() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_l63_blank_fragment1, container, false);
        
        return view;
    }

}

package com.example.mob202l6fragment.l62loadfragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mob202l6fragment.R;

public class L62Main2Activity extends AppCompatActivity {
    Button button;
    L621BlankFragment frm1;
    L622BlankFragment frm2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l62_main2);
        button = findViewById(R.id.activity_l622_btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Anh xa 2 fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                frm1 = (L621BlankFragment)fragmentManager.findFragmentById(R.id.fragment_l62_1);
                frm2 = (L622BlankFragment)fragmentManager.findFragmentById(R.id.fragment_l62_2);
                fragmentManager.beginTransaction()
                      //  .hide(frm1) -> an
                      //  .remove(frm2)-> xoa
                      //  .show(frm1) -> hien thi
                        .commit();
            }
        });
    }
}

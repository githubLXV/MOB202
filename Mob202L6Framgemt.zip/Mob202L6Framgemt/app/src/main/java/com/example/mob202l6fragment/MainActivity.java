package com.example.mob202l6fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btn61Send;
    EditText txt61Send;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn61Send = findViewById(R.id.btn61Send);
        txt61Send = findViewById(R.id.txt61Send);
        btn61Send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //1. Goi 1 fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                //2. anh xa fragment
                BlankFragmentl61 blankFragmentl61
                        =(BlankFragmentl61)fragmentManager.findFragmentById(R.id.fragl611);
                //3. truy cap thanh phan con cua fragment
                blankFragmentl61.txtSend.setText(txt61Send.getText().toString());
            }
        });
    }
}
